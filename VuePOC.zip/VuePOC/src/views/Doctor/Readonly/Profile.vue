<template>
    
<div id="activityDetailsContainer">
  <section>
          <div class="float-right">
              <a href="#" class="btn btn-link" id="btnEditConditionDetails"><span class="fas fa-fw fa-edit"></span>Edit</a>
          </div>
      <h2>Doctor Details</h2>
  </section>

<section id="previewConditionDetails">
	<table class="table w-100">
		<tbody>
			<tr>
				<td class="w-50"><strong>First Name</strong></td>
				<td>Ramesh</td>
			</tr>
			<tr>
				<td class="w-50"><strong>Last Name</strong></td>
				<td>Agrawal</td>
			</tr>
			<tr>
				<td class="w-50"><strong>Type</strong></td>
				<td>Surgon</td>
			</tr>
			<tr>
				<td class="w-50"><strong>Joined Date</strong></td>
				<td>
					10/03/2019
				</td>
			</tr>
			<tr>
				<td class="w-50"><strong>Address</strong></td>
				<td>Dalal Street</td>
			</tr>
		</tbody>
	</table>

	<h3>Patient Attended</h3>
	<table class="table w-100">
		<tbody>

			<tr>
				<td class="w-50"><strong>IPD</strong></td>
				<td class="w-50">
					10
				</td>
			</tr>
			<tr>
				<td class="w-50"><strong>OPD</strong></td>
				<td class="w-50">
					20
				</td>
			</tr>
			<tr>
				<td class="w-50"><strong>Surgery</strong></td>
				<td class="w-50">
					10
				</td>
			</tr>

		</tbody>
	</table>
</section>

</div>
 </template>
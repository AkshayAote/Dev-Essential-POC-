<template>
    
<div>
	<section>
		<table class="table w-100">
			<tbody>
				<tr>
					<td class="w-50"><strong>Bill Detailing View</strong></td>
					<td>Bill Detail</td>
				</tr>
			</tbody>
		</table>
	</section>
</div>
 </template>
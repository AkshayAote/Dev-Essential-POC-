<template>
    <table class="table">
        <thead class="thead-dark">
            <tr>
            <th colspan="4" scope="col">Billing Process</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                    <td>
                          <router-link to="/dashboard/bill/1">Payment Link</router-link>
                    </td>
            </tr>
        </tbody>
    </table>
</template>

<template>
    
<div id="activityDetailsContainer">
  <section>
          <div class="float-right">
              <a href="#" class="btn btn-link" id="btnEditConditionDetails"><span class="fas fa-fw fa-edit"></span>Edit</a>
          </div>
      <h2>Service</h2>
  </section>

<section id="previewConditionDetails">
	<table class="table w-100">
		<tbody>
			<tr>
				<td class="w-50"><strong>Name</strong></td>
				<td>ICU</td>
			</tr>
			<tr>
				<td class="w-50"><strong>Charges</strong></td>
				<td>2000</td>
			</tr>
			<tr>
				<td class="w-50"><strong>Status</strong></td>
				<td>
					<span class="badge badge-success">Active</span>
				</td>
			</tr>

		</tbody>
	</table>
</section>

</div>
 </template>
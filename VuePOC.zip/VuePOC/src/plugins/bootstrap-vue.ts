import Vue from "vue";

import BoostrapVue from "bootstrap-vue";
import "bootstrap/dist/css/bootstrap.min.css";

Vue.use(BoostrapVue)
